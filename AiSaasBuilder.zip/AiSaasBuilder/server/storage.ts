import session from "express-session";
import createMemoryStore from "memorystore";
import { Component, InsertComponent, InsertUser, User } from "@shared/schema";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getComponents(userId: number): Promise<Component[]>;
  createComponent(userId: number, component: Omit<InsertComponent, "userId">): Promise<Component>;
  updateComponentPosition(componentId: number, position: number): Promise<void>;
  deleteComponent(componentId: number): Promise<void>;
  
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private components: Map<number, Component>;
  private currentUserId: number;
  private currentComponentId: number;
  readonly sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.components = new Map();
    this.currentUserId = 1;
    this.currentComponentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getComponents(userId: number): Promise<Component[]> {
    return Array.from(this.components.values()).filter(
      (component) => component.userId === userId,
    ).sort((a, b) => a.position - b.position);
  }

  async createComponent(
    userId: number,
    component: Omit<InsertComponent, "userId">,
  ): Promise<Component> {
    const id = this.currentComponentId++;
    const newComponent: Component = {
      ...component,
      id,
      userId,
    };
    this.components.set(id, newComponent);
    return newComponent;
  }

  async updateComponentPosition(componentId: number, position: number): Promise<void> {
    const component = this.components.get(componentId);
    if (component) {
      this.components.set(componentId, { ...component, position });
    }
  }

  async deleteComponent(componentId: number): Promise<void> {
    this.components.delete(componentId);
  }
}

export const storage = new MemStorage();
