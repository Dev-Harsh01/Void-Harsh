import { Component } from "@shared/schema";

const DEEPSEEK_API_KEY = "sk-1b70166f52984dce8ac5083f24dee1e1";
const DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions";

export async function analyzeDataAndGenerateComponent(
  csvData: string,
  prompt: string
): Promise<Omit<Component, "id" | "userId">> {
  try {
    const response = await fetch(DEEPSEEK_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${DEEPSEEK_API_KEY}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [
          {
            role: "system",
            content: 
              "You are a data analysis assistant. Analyze the given CSV data and generate a visualization component. " +
              "The response should be a JSON object with the following structure: " +
              "{ 'name': string, 'type': 'chart' | 'kpi' | 'table', 'configuration': object }"
          },
          {
            role: "user",
            content: `CSV Data:\n${csvData}\n\nPrompt: ${prompt}\n\nAnalyze this data and suggest an appropriate visualization.`
          }
        ],
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      if (response.status === 429) {
        throw new Error("DeepSeek API rate limit exceeded. Please try again later.");
      }
      throw new Error(`DeepSeek API error: ${response.statusText}`);
    }

    const result = await response.json();
    return result.choices[0].message.content;
  } catch (error: any) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    throw new Error("Failed to generate component: " + message);
  }
}
