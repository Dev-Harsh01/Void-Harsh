import Papa from "papaparse";
import { Component } from "@shared/schema";

export function analyzeDataAndGenerateComponent(
  csvData: string,
  prompt: string
): Omit<Component, "id" | "userId"> {
  try {
    // Parse CSV data with explicit parsing options
    const parseResult = Papa.parse(csvData, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true, // Automatically convert numeric values
    });

    if (parseResult.errors.length > 0) {
      throw new Error("Failed to parse CSV: " + parseResult.errors[0].message);
    }

    // Validate data
    if (!parseResult.data || parseResult.data.length === 0) {
      throw new Error("CSV file is empty");
    }

    // Get column names
    const columns = Object.keys(parseResult.data[0] as object);
    if (columns.length === 0) {
      throw new Error("No columns found in CSV data");
    }

    // Create a simple table view of the data
    return {
      name: "Data Table",
      type: "table",
      position: 0,
      configuration: {
        columns: columns,
        data: parseResult.data.slice(0, 10) // Show first 10 rows
      }
    };
  } catch (error: any) {
    const message = error instanceof Error ? error.message : "An unknown error occurred";
    throw new Error("Failed to analyze data: " + message);
  }
}