import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertComponentSchema } from "@shared/schema";
import { analyzeDataAndGenerateComponent } from "./analysis";
import multer from "multer";

const upload = multer();

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Get all components for the current user
  app.get("/api/components", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const components = await storage.getComponents(req.user.id);
    res.json(components);
  });

  // Generate and create a new component from CSV data
  app.post("/api/components/generate", upload.single('file'), async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ message: "Prompt is required" });
    }

    if (!req.file) {
      return res.status(400).json({ message: "CSV file is required" });
    }

    try {
      const csvData = req.file.buffer.toString('utf-8');
      const componentSpec = await analyzeDataAndGenerateComponent(csvData, prompt);
      const position = (await storage.getComponents(req.user.id)).length;

      const component = await storage.createComponent(req.user.id, {
        ...componentSpec,
        position,
      });

      res.json(component);
    } catch (error: any) {
      const message = error instanceof Error ? error.message : "An unknown error occurred";
      res.status(500).json({ message });
    }
  });

  // Update component position
  app.patch("/api/components/:id/position", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const { position } = req.body;
    if (typeof position !== "number") {
      return res.status(400).json({ message: "Position must be a number" });
    }

    await storage.updateComponentPosition(parseInt(req.params.id), position);
    res.sendStatus(200);
  });

  // Delete a component
  app.delete("/api/components/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.deleteComponent(parseInt(req.params.id));
    res.sendStatus(200);
  });

  const httpServer = createServer(app);
  return httpServer;
}